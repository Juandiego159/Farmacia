export class Producto {
  idProducto: number
  nombre: string
  descripcion: string
  precioventa: number
  categoria: string
  proveedor: string
}
