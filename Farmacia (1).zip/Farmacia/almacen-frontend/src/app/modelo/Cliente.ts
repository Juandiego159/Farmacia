export class Cliente {
  idCliente: number
  nombre: string
  apellido: string
  telefono: string
  direccion: string
  contrasena: string
  tipoCliente: string
}
