import {Component, Inject, OnInit, ViewChild} from '@angular/core';
import {FormControl, FormGroup, FormsModule, NgForm, ReactiveFormsModule, Validators} from "@angular/forms";
import {MAT_DIALOG_DATA, MatDialogContent, MatDialogRef} from "@angular/material/dialog";
import {switchMap} from "rxjs";
import {Producto} from "../../../modelo/Producto";
import {ProductoService} from "../../../servicio/producto.service";
import {MatButton} from "@angular/material/button";
import {MatFormField} from "@angular/material/form-field";
import {MatInput} from "@angular/material/input";
import {MatToolbar} from "@angular/material/toolbar";

@Component({
  selector: 'app-form-producto',
  standalone: true,
  imports: [
    FormsModule,
    MatButton,
    MatDialogContent,
    MatFormField,
    MatInput,
    MatToolbar,
    ReactiveFormsModule
  ],
  templateUrl: './form-producto.component.html',
  styleUrl: './form-producto.component.css'
})
export class FormProductoComponent implements OnInit {
  @ViewChild('ProductoForm') productoForm!: NgForm ;
  form: FormGroup;

  constructor(
    @Inject(MAT_DIALOG_DATA) private data: Producto,
    private krService: ProductoService,
    private _dialogRef: MatDialogRef<FormProductoComponent>

  ){}
  ngOnInit(): void {
    if(this.data!==undefined){
      console.log(this.data['nombre']);
      console.log(this.data['descripcion']);
      console.log(this.data['precioventa']);
      console.log(this.data['categoria']);
      console.log(this.data['proveedor']);

      this.form = new FormGroup({
        idProducto: new FormControl(this.data['idProducto']),
        nombre: new FormControl(this.data['nombre'], [Validators.required, Validators.minLength(3), Validators.maxLength(50)]),
        descripcion: new FormControl(this.data['descripcion'], [Validators.required, Validators.minLength(3), Validators.maxLength(50)]),
        precioventa: new FormControl(this.data['precioventa'], [Validators.required]),
        categoria: new FormControl(this.data['categoria'], [Validators.required, Validators.minLength(3), Validators.maxLength(50)]),
        proveedor: new FormControl(this.data['proveedor'], [Validators.required, Validators.minLength(3), Validators.maxLength(50)])
      });


    }else{
      this.form = new FormGroup({
        idProducto: new FormControl(0),
        nombre: new FormControl('', [Validators.required, Validators.minLength(3), Validators.maxLength(50)]),
        descripcion: new FormControl('', [Validators.required, Validators.minLength(3), Validators.maxLength(50)]),
        precioventa: new FormControl('', [Validators.required]),
        categoria: new FormControl('', [Validators.required, Validators.minLength(3), Validators.maxLength(50)]),
        proveedor: new FormControl('', [Validators.required, Validators.minLength(3), Validators.maxLength(50)])
      });
    }
  }

  close(){
    this._dialogRef.close();
  }

  operate(){
    const producto: Producto = new Producto();
    producto.idProducto = this.form.value['idProducto'];
    producto.nombre = this.form.value['nombre'];
    producto.descripcion = this.form.value['descripcion'];
    producto.precioventa = this.form.value['precioventa'];
    producto.categoria = this.form.value['categoria'];
    producto.proveedor = this.form.value['proveedor'];

    if(this.productoForm.valid){
      if(producto.idProducto > 0){
        //UPDATE
        this.krService.update(producto.idProducto, producto)
          .pipe(switchMap( ()=> this.krService.findAll() ))
          .subscribe(data => {
            this.krService.setProductoChange(data);
            this.krService.setMessageChange('UPDATED!');
            this.close();
          });

      }else{
        //INSERT
        this.krService.save(producto)
          .pipe(switchMap( ()=> this.krService.findAll() ))
          .subscribe(data => {
            this.krService.setProductoChange(data);
            this.krService.setMessageChange('CREATED!');
            this.close();
          });
      }
    }else{
      console.log("Error....")
    }

  }

  get f(){
    return this.form.controls;
  }

}
