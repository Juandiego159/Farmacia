import { Routes } from '@angular/router';
import {MainCargoComponent} from "./main-cargo/main-cargo.component";
import {FormCargoComponent} from "./main-cargo/form-cargo/form-cargo.component";
import {MainCategoriaComponent} from "./main-categoria/main-categoria.component";
import {FormCategoriaComponent} from "./main-categoria/form-categoria/form-categoria.component";
import {MainClienteComponent} from "./main-cliente/main-cliente.component";
import {FormClienteComponent} from "./main-cliente/form-cliente/form-cliente.component";
import {MainEstadoComponent} from "./main-estado/main-estado.component";
import {FormEstadoComponent} from "./main-estado/form-estado/form-estado.component";
import {MainProductoComponent} from "./main-producto/main-producto.component";
import {FormProductoComponent} from "./main-producto/form-producto/form-producto.component";
import {DashboardComponent} from "./dashboard/dashboard.component";
import {certGuard} from "../guard/cert.guard";
import {Not403Component} from "./not403/not403.component";

export const pagesRoutes: Routes = [
  { path: 'dashboard', component: DashboardComponent, canActivate:[certGuard] },

  {
    path: 'cargo',
    component: MainCargoComponent,
    children: [
      { path: 'new', component: FormCargoComponent },
      { path: 'edit/:id', component: FormCargoComponent },
    ], canActivate:[certGuard]
  },
  {
    path: 'categoria',
    component: MainCategoriaComponent,
    children: [
      { path: 'new', component: FormCategoriaComponent },
      { path: 'edit/:id', component: FormCategoriaComponent },
    ], canActivate:[certGuard]
  },
  {
    path: 'cliente',
    component: MainClienteComponent,
    children: [
      { path: 'new', component: FormClienteComponent },
      { path: 'edit/:id', component: FormClienteComponent },
    ], canActivate:[certGuard]
  },
  {
    path: 'estado',
    component: MainEstadoComponent,
    children: [
      { path: 'new', component: FormEstadoComponent },
      { path: 'edit/:id', component: FormEstadoComponent },
    ], canActivate:[certGuard]
  },
  {
    path: 'producto',
    component: MainProductoComponent,
    children: [
      { path: 'new', component: FormProductoComponent },
      { path: 'edit/:id', component: FormProductoComponent },
    ], canActivate:[certGuard]
  },
  { path: 'not-403', component: Not403Component},


];
