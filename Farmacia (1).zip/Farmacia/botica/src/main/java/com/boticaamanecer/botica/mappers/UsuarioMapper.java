package com.boticaamanecer.botica.mappers;

import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import com.boticaamanecer.botica.dtos.UsuarioDTO;
import com.boticaamanecer.botica.modelo.Usuario;

@Mapper(componentModel = "spring")
public interface UsuarioMapper extends GenericMapper<UsuarioDTO, Usuario> {

    @Mapping(target = "clave", ignore = true)
    Usuario toEntityFromCADTO(UsuarioDTO.UsuarioCrearDto usuarioCrearDto);
}
