package com.boticaamanecer.botica.servicio;



import com.boticaamanecer.botica.modelo.Rol;

import java.util.Optional;

public interface IRolService extends ICrudGenericoService<Rol, Long>{
    public Optional<Rol> getByNombre(Rol.RolNombre rolNombre);
}