package com.boticaamanecer.botica;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BoticaApplication {

	public static void main(String[] args) {
		SpringApplication.run(BoticaApplication.class, args);
	}

}
