package com.boticaamanecer.botica.mappers;

import com.boticaamanecer.botica.dtos.CargoDTO;
import com.boticaamanecer.botica.modelo.Cargo;
import org.mapstruct.Mapper;

@Mapper(componentModel = "spring")
public interface CargoMapper extends GenericMapper<CargoDTO, Cargo> {
}
