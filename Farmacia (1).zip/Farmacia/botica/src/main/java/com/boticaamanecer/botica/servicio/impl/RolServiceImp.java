package com.boticaamanecer.botica.servicio.impl;

import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import com.boticaamanecer.botica.modelo.Rol;
import com.boticaamanecer.botica.repositorio.ICrudGenericoRepository;
import com.boticaamanecer.botica.repositorio.IRolRepository;
import com.boticaamanecer.botica.servicio.IRolService;

import java.util.Optional;

@Service
@Transactional
@RequiredArgsConstructor
public class RolServiceImp extends CrudGenericoServiceImp<Rol, Long> implements IRolService {
    private final IRolRepository repo;
    @Override
    protected ICrudGenericoRepository<Rol, Long> getRepo() {
        return repo;
    }
    @Override
    public Optional<Rol> getByNombre(Rol.RolNombre rolNombre) {
        return repo.findByNombre(rolNombre);
    }

}
