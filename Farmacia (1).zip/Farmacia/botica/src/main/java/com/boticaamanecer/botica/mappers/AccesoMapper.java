package com.boticaamanecer.botica.mappers;

import org.mapstruct.Mapper;
import com.boticaamanecer.botica.dtos.AccesoDTO;
import com.boticaamanecer.botica.modelo.Acceso;

@Mapper(componentModel = "spring")
public interface AccesoMapper extends GenericMapper<AccesoDTO, Acceso> {
}