package com.boticaamanecer.botica.repositorio;

import com.boticaamanecer.botica.modelo.Categoria;

public interface CategoriaRepository extends ICrudGenericoRepository<Categoria, Long> {
}
