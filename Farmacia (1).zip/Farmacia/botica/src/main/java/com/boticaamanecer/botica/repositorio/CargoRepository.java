package com.boticaamanecer.botica.repositorio;

import com.boticaamanecer.botica.modelo.Cargo;

public interface CargoRepository extends ICrudGenericoRepository<Cargo, Long>{
}
