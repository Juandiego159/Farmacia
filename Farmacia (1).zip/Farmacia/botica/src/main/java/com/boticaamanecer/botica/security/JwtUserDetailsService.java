package com.boticaamanecer.botica.security;



import lombok.RequiredArgsConstructor;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;
import com.boticaamanecer.botica.modelo.Usuario;
import com.boticaamanecer.botica.modelo.UsuarioRol;
import com.boticaamanecer.botica.repositorio.IUsuarioRepository;
import com.boticaamanecer.botica.repositorio.IUsuarioRolRepository;

import java.util.ArrayList;
import java.util.List;

//Clase S4
@Service
@RequiredArgsConstructor
public class JwtUserDetailsService implements UserDetailsService {

    private final IUsuarioRolRepository repo;
    private final IUsuarioRepository repoU;

    @Override
    public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {
        // Buscar al usuario por su nombre de usuario
        Usuario u = repoU.findOneByUser(username).orElse(null);

        if (u == null) {
            throw new UsernameNotFoundException("Username not found: " + username);  // Manejo explícito si no se encuentra el usuario
        }

        // Buscar los roles del usuario
        List<UsuarioRol> userRoles = repo.findOneByUsuarioUser(username);

        if (userRoles == null || userRoles.isEmpty()) {
            throw new UsernameNotFoundException("No roles assigned to the user: " + username);  // Manejo si no se encuentran roles
        }

        // Crear la lista de autoridades (roles)
        List<GrantedAuthority> roles = new ArrayList<>();
        userRoles.forEach(rol -> {
            roles.add(new SimpleGrantedAuthority(rol.getRol().getNombre().name()));
        });

        // Crear y devolver un objeto UserDetails
        return new org.springframework.security.core.userdetails.User(u.getUser(), u.getClave(), roles);
    }

}
