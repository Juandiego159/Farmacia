package com.boticaamanecer.botica.dtos;

import jakarta.validation.constraints.NotNull;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@NoArgsConstructor
@AllArgsConstructor
@Data
public class ClienteDTO {
    private Long idCliente;
    @NotNull(message = "El nombre no puede ser nulo")
    private String nombre;
    @NotNull(message = "El apellido no puede ser nulo")
    private String apellido;
    @NotNull(message = "El telefono no puede ser nulo")
    private String telefono;
    @NotNull(message = "El direccion no puede ser nulo")
    private String direccion;
    @NotNull(message = "El contraseña no puede ser nulo")
    private String contrasena;
    @NotNull(message = "El tipoCliente no puede ser nulo")
    private String tipoCliente;

}
