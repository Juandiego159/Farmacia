package com.boticaamanecer.botica.mappers;

import com.boticaamanecer.botica.dtos.ProductoDTO;
import com.boticaamanecer.botica.modelo.Producto;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;

@Mapper(componentModel = "spring")
public interface ProductoMapper extends GenericMapper<ProductoDTO, Producto> {
}
