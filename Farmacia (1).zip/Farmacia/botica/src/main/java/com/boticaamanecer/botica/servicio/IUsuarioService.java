package com.boticaamanecer.botica.servicio;

import com.boticaamanecer.botica.dtos.UsuarioDTO;
import com.boticaamanecer.botica.modelo.Usuario;

public interface IUsuarioService extends ICrudGenericoService<Usuario, Long>{
    public UsuarioDTO login(UsuarioDTO.CredencialesDto credentialsDto);
    public UsuarioDTO register(UsuarioDTO.UsuarioCrearDto userDto);
}