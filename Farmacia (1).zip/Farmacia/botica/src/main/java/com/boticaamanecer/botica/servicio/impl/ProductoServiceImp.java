package com.boticaamanecer.botica.servicio.impl;


import com.boticaamanecer.botica.modelo.Producto;
import com.boticaamanecer.botica.repositorio.ICrudGenericoRepository;
import com.boticaamanecer.botica.repositorio.ProductoRepository;
import com.boticaamanecer.botica.servicio.ProductoService;
import jakarta.transaction.Transactional;
import lombok.RequiredArgsConstructor;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;

@Service
@Transactional
@RequiredArgsConstructor
public class ProductoServiceImp extends CrudGenericoServiceImp<Producto, Long> implements ProductoService {
    private final ProductoRepository repo;

    @Override
    protected ICrudGenericoRepository<Producto, Long> getRepo() { return repo; }

    public Page<Producto> listaPage(Pageable pageable){
        return repo.findAll(pageable);
    }
}
