package com.boticaamanecer.botica.control;

import com.boticaamanecer.botica.dtos.EstadoDTO;
import com.boticaamanecer.botica.mappers.EstadoMapper;
import com.boticaamanecer.botica.modelo.Estado;
import com.boticaamanecer.botica.servicio.EstadoService;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.support.ServletUriComponentsBuilder;

import java.net.URI;
import java.util.List;

@RequiredArgsConstructor
@RestController
@RequestMapping("/estados")
@CrossOrigin("*")
public class EstadoController {
    private final EstadoService servicekr;
    private final EstadoMapper mapperkr;
    @GetMapping
    public ResponseEntity<List<EstadoDTO>> findAll() {
        List<EstadoDTO> list = mapperkr.toDTOs(servicekr.findAll());
        return ResponseEntity.ok(list);
    }
    @GetMapping("/{id}")
    public ResponseEntity<EstadoDTO> findById(@PathVariable("id") Long id) {
        Estado obj = servicekr.findById(id);
        return ResponseEntity.ok(mapperkr.toDTO(obj));
    }
    @PostMapping
    public ResponseEntity<Void> save(@Valid @RequestBody EstadoDTO dto) {
        Estado obj = servicekr.save(mapperkr.toEntity(dto));
        URI location = ServletUriComponentsBuilder.fromCurrentRequest().path("/{id}").buildAndExpand(obj.getIdEstado()).toUri();
        return ResponseEntity.created(location).build();
    }
    @PutMapping("/{id}")
    public ResponseEntity<EstadoDTO> update(@Valid @PathVariable("id") Long id, @RequestBody EstadoDTO dto) {
        dto.setIdEstado(id);
        Estado obj = servicekr.update(id, mapperkr.toEntity(dto));
        return ResponseEntity.ok(mapperkr.toDTO(obj));
    }
    @DeleteMapping("/{id}")
    public ResponseEntity<Void> delete(@PathVariable("id") Long id) {
        servicekr.delete(id);
        return ResponseEntity.noContent().build();
    }
}
