package com.boticaamanecer.botica.mappers;

import com.boticaamanecer.botica.dtos.EstadoDTO;
import com.boticaamanecer.botica.modelo.Estado;
import org.mapstruct.Mapper;

@Mapper(componentModel = "spring")
public interface EstadoMapper extends GenericMapper<EstadoDTO, Estado> {
}
