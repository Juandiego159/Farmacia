package com.boticaamanecer.botica.mappers;

import com.boticaamanecer.botica.dtos.ClienteDTO;
import com.boticaamanecer.botica.modelo.Cliente;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;

@Mapper(componentModel = "spring")
public interface ClienteMapper extends GenericMapper<ClienteDTO, Cliente> {
}
