package com.boticaamanecer.botica.servicio;

import com.boticaamanecer.botica.modelo.Acceso;

import java.util.List;

public interface IAccesoService {
    List<Acceso> getAccesoByUser(String username);
}
