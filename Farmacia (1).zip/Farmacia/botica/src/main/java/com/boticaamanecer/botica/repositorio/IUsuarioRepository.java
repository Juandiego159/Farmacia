package com.boticaamanecer.botica.repositorio;

import com.boticaamanecer.botica.modelo.Usuario;

import java.util.Optional;

public interface IUsuarioRepository extends ICrudGenericoRepository<Usuario, Long>{

    Optional<Usuario> findOneByUser(String user);
}
