package com.boticaamanecer.botica;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BoticaApplicationTests {

	@Test
	void contextLoads() {
	}

}
